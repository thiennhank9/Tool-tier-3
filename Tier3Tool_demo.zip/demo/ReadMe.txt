Please follow these steps to setup and using the web tool of tier3 to query data in Warehouses.

1. Follow file "Guide_Install.docx" to setup.

2. Follow file "Guide_Uses.docx" to know how to use this web tool.

The accounts information is in file "Accounts.txt".